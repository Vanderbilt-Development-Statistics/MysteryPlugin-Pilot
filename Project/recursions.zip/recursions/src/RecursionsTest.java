// File name: RecursionsTest.java
// Description: Tests for the recursive programming methods
// Last Changed: April 17, 2026

// Testing the recursive programming lab

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RecursionsTest {

    // Here are some initial JUnit tests of the functions you are to implement.
    // You should add tests of your own to fully test the functions. The provided
    // tests do not constitute thorough/complete testing.


    @Test
    public void testSumArray() {
        int[] test = {1, 2, 3, 4, 5};
        assertEquals(15, Recursions.sumArray(test,5));
    }

    @Test
    public void testMember() {
        int[] tmp = {12, 13, 21, 30, 2, 55, 1000, 5, 201, 789};
        assertTrue(Recursions.member(55, tmp, 10));
    }

    @Test
    public void testIsPalindrome() {
        assertTrue(Recursions.isPalindrome("abcdeedcba"));
    }

    @Test
    public void testAddStar() {
        assertEquals("a*b*c", Recursions.addStar("abc"));
    }

    @Test
    public void testMoveXs() {
        assertEquals("rexx", Recursions.moveXs("xxre"));
    }

    @Test
    public void testConvert2Binary() {
        assertEquals("11001", Recursions.convert2Binary(25));
        System.out.print("Testing convert2Binary: ");
        System.out.println("The first ten binary numbers are: ");
        for (int j=0; j<10; j++)
        {
            System.out.println(j + " = " + Recursions.convert2Binary(j));
        }
        System.out.println();
    }

    @Test
    public void testReverseArray() {
        int[] tmp2 = {789, 201, 5, 1000, 55, 2, 30, 21, 13, 12};
        int[] tmp3 = {12, 13, 21, 30, 2, 55, 1000, 5, 201, 789};
        Recursions.reverseArray(tmp2, 0, 9);
        assertArrayEquals(tmp3, tmp2);
    }

    @Test
    public void testNumOfTerms() {
        // create a linked list
        Recursions.Node head = null;
        Recursions.Node tmpPtr;
        int cnt = 0;
        for (int k=0; k<20; k++)
        {
            tmpPtr = new Recursions.Node();
            tmpPtr.value = ((k%3)==0) ? 0 : k%10;
            if (tmpPtr.value != 0) cnt++;
            tmpPtr.next = head;
            head = tmpPtr;
        }
        assertEquals(cnt, Recursions.numOfTerms(head));
    }

    @Test
    public void testEcho2() {
        // create a linked list
        Recursions.Node head = null;
        Recursions.Node tmpPtr;
        for (int k=0; k<10; k++)
        {
            tmpPtr = new Recursions.Node();
            tmpPtr.value = ((k%3)==0) ? 0 : k%10;
            tmpPtr.next = head;
            head = tmpPtr;
        }
        assertEquals("0 8 7 0 5 4 0 2 1 0 0 1 2 0 4 5 0 7 8 0 ", Recursions.echo2(head));
    }


    @Test
    public void testContains() {
        // create a linked list
        Recursions.Node superList = null;
        Recursions.Node tmpPtr;

        for (int k=0; k<20; k++)
        {
            tmpPtr = new Recursions.Node();
            tmpPtr.value = ((k%4)==0) ? 0 : k;
            tmpPtr.next = superList;
            superList = tmpPtr;
        }

        Recursions.Node subList = null;
        for (int k=7; k<20; k=k+2)
        {
            tmpPtr = new Recursions.Node();
            tmpPtr.value = (((k-1)%4)==0) ? 0 : k;
            tmpPtr.next = subList;
            subList = tmpPtr;
        }

        assertTrue(Recursions.contains(superList,subList));
        superList = superList.next;
        assertFalse(Recursions.contains(superList,subList));
        subList = subList.next;
        assertTrue(Recursions.contains(superList,subList));
        subList = subList.next.next.next;
        assertTrue(Recursions.contains(superList,subList));
        subList.next.value = 666;
        assertFalse(Recursions.contains(superList,subList));
    }


    // print a space-separated list of numbers from a linked-list
    public static void printList(Recursions.Node head)
    {

        System.out.print("contents of list: ");
        for (Recursions.Node cur = head; cur != null; cur = cur.next) {
            System.out.print(cur.value + " ");
        }
        System.out.println("Done");

    }


    // return a space-separated list of numbers from a linked-list
    public static String list2String(Recursions.Node head)
    {
        String result="";
        for (Recursions.Node cur = head; cur != null; cur = cur.next) {
            result += cur.value + " ";
        }
        return result;
    }
}
