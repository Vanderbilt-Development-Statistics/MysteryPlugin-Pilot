// Name:
// File name: RecursionsDemo.java
// Description: An executable program to try your recursive functions
// Last Changed: April 17, 2026


import java.util.Arrays;

public class RecursionsDemo {
    public static void main(String[] args) {

        // feel free to add code here to play around with your recursive functions

        int[] tmpArr = {1, 2, 3, 4, 5};

        System.out.print("The sum of the elements in the array ");
        System.out.print(Arrays.toString(tmpArr));
        System.out.print(" is ");
        System.out.println(Recursions.sumArray(tmpArr,5));


    }
}
