// Name:
// File name: Recursions.java
// Description: Recursive programming methods
// Last Changed: April 17, 2026

// Recursive programming lab

// NOTE: your implementation of these functions must be recursive.
// NO LOOPS ARE ALLOWED.
// Please read the project spec for other restrictions.

// NOTE: the functions in this file are not listed in any particular order.
// In particular, they are not listed easiest to hardest. You are not
// required to implement them in the order given, so jump around and do
// the easy ones, or the ones that make sense to you, first.

// NOTE: if for some reason you fail to complete a function listed here,
// please just leave the declaration with the provided dummy code. That will
// ensure our grading script will at least compile with your submission.

// NOTE: you should remove the TODO comment once you have implemented a function.
// Failure to do so will result in a style penalty.

public class Recursions {

    //Task: compute the sum of the first size elements of an array of integers
    //Pre: anArray is an array of integers, 0<=size<=anArray.length
    //Post: the sum of anArray[0]...anArray[size-1] is returned
    //Additional requirement: do not make new arrays
    public static int sumArray(int[] anArray, int size) {
        return -12345;  // TODO replace this with your solution
    }



    //Task: determine if target is in the set
    //Pre: set is an array of 'size' integers, size is non-negative
    //Post: true is returned if target is in the set, else false;
    //  the set is unchanged
    //Additional requirement: do not make new arrays
    public static boolean member(int target, int[] set, int size) {
        return false;  // TODO replace this with your solution
    }



    //Task: determine if a string is a palindrome
    //Pre: str is a string object
    //Post: returns true if str is a palindrome, otherwise returns false
    //      The test is case-insensitive [look up Character.toUpperCase() and
    //      Character.toLowerCase()]. You do not need to worry about
    //      trimming blanks from the ends of the string.
    //Note: the empty string is a palindrome
    public static boolean isPalindrome(String str) {
        return false;  // TODO replace this with your solution
    }



    // Task: Given a string, compute recursively a new string where all the adjacent
    //   chars are now separated by a "*".
    // Pre: str is a string (it may be empty).
    // Post: a correctly starred string is returned.
    // Examples:
    //   addStar("hello") --> "h*e*l*l*o"
    //   addStar("abc") --> "a*b*c"
    //   addStar("ab") --> "a*b"
    public static String addStar(String str) {
        return "ERROR";  // TODO replace this with your solution
    }



    // Task: Given a string, compute recursively a new string where all the lowercase 'x' chars
    //   have been moved to the end of the string.
    // Pre: str is a string (possibly empty)
    // Post: return a new string where all lowercase 'x' chars have been moved to the end
    // Examples:
    //   moveXs("xxre") --> "rexx"
    //   moveXs("xxhixx") --> "hixxxx"
    //   moveXs("xhixhix") --> "hihixxx"
    public static String moveXs(String str) {
        return "ERROR";  // TODO replace this with your solution
    }



    // Task: produce the binary representation of a decimal number
    //   A decimal number is converted to binary by repeated
    //   division by 2. For each division, keep track of the quotient
    //   and remainder. The remainder becomes the low-order bit (rightmost
    //   bit) of the binary representation. The higher-order bits are
    //   determined by repeating the processes with the quotient.
    //   The process stops when num is either zero or one.
    // Pre: num is a non-negative integer
    // Post: the binary representation of num is produced and returned
    //   as a string.
    // To convert an integer to a string you can use Integer.toString().
    public static String convert2Binary(int num) {
        return "ERROR";  // TODO replace this with your solution
    }



    // Task: reverse the contents of a[first]...a[last]
    // Pre: 'a' is an array of at least 'last'+1 integers, first & last are non-negative
    // Post: the elements a[first]...a[last] have been reversed.
    public static void reverseArray(int[] a, int first, int last) {
        return;  // TODO replace this with your solution
    }



    // Definition of a Node for linked list problems
    // DO NOT CHANGE THE DEFINITION OF THIS NODE
    public static class Node {
        public int value;
        public Node next;
    }



    // Task: Count the number of nodes with a nonzero value in a linked list
    // Pre: head points to the first node of the list, or it is null if the list is empty
    // Post: the number of nodes with a nonzero value in the linked list is returned, and
    //  the linked list is unchanged.
    public static int numOfTerms(Node head) {
        return -12345;  // TODO replace this with your solution
    }



    // Task: Return a string of the contents of the linked list in forward order and then
    //    the same values in reverse order.
    // Pre: tmp points to the first node of the list, or it is null if
    //  the list is empty
    // Post: returns a string of the values of all nodes in the linked list in forward
    //  order, and then the same values in reverse order, with a single space after each
    //  and every value. The linked list is unchanged.
    // Ex: if the list contains 1 2 3, we will return "1 2 3 3 2 1 "
    public static String echo2(Node tmp) {
        return "ERROR";  // TODO replace this with your solution
    }



    // Task: Find out whether a linked list 'subList' is contained within another
    //   linked list 'superList'
    // Pre: superList and subList are head pointers to non-empty linked lists
    // Post: Return true or false depending on whether subList is contained in superList
    // A list is contained in another list if all the data elements appear in the
    // same relative order. For example...
    // If superList was 2->13->5->6->10->21 and subList was 13->5->10 then contains would be true.
    // If superList was 2->13->5->6->10->21 and subList was 5->13->10 then contains would be false.
    // If superList was 2->13->5->6->10 and subList was 13->7->10 then contains would return false.
    public static boolean contains(Node superList, Node subList) {
        return false;  // TODO replace this with your solution
    }
}
